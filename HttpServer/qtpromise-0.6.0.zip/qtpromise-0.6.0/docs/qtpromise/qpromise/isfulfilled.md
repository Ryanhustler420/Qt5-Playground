---
title: .isFulfilled
---

# QPromise::isFulfilled

*Since: 0.1.0*

```cpp
QPromise<T>::isFulfilled() -> bool
```

Returns `true` if the promise is fulfilled, otherwise returns `false`.
