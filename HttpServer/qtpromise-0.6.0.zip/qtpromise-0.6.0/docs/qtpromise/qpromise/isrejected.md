---
title: .isRejected
---

# QPromise::isRejected

*Since: 0.1.0*

```cpp
QPromise<T>::isRejected() -> bool
```

Returns `true` if the promise is rejected, otherwise returns `false`.
